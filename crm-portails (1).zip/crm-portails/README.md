# PortailCRM — Guide de déploiement

## Contenu du dossier
- `index.html` — Application principale (CRM complet)
- `config.json` — Configuration des listes déroulantes et paramètres
- `manifest.json` — Pour l'installation en raccourci sur mobile

---

## Déploiement sur Netlify (gratuit, recommandé)

1. Crée un compte sur https://netlify.com
2. Glisse-dépose le dossier `crm-portails` directement sur la page Netlify
3. Ton CRM sera en ligne en moins de 30 secondes avec une URL du type `https://xyz.netlify.app`

---

## Déploiement sur GitHub Pages (gratuit)

1. Crée un compte sur https://github.com
2. Crée un nouveau dépôt (repository) public
3. Upload les 3 fichiers (`index.html`, `config.json`, `manifest.json`)
4. Va dans Settings → Pages → Source: main branch
5. Ton CRM sera accessible sur `https://tonnom.github.io/nom-repo`

---

## Ajouter le raccourci sur l'écran d'accueil

### Sur iPhone / iPad (Safari)
1. Ouvre l'URL du CRM dans Safari
2. Appuie sur l'icône Partager (carré avec flèche)
3. Sélectionne "Sur l'écran d'accueil"
4. Nomme-le "PortailCRM" et appuie sur Ajouter

### Sur Android (Chrome)
1. Ouvre l'URL dans Chrome
2. Menu (3 points) → "Ajouter à l'écran d'accueil"
3. Confirme l'ajout

### Sur PC / Mac (Chrome)
1. Ouvre l'URL dans Chrome
2. Clique sur l'icône d'installation dans la barre d'adresse (ou Menu → "Installer PortailCRM")

---

## Modifier les listes déroulantes

### Depuis l'interface (recommandé)
Connecte-toi en tant qu'Admin → menu "Paramètres" → modifie chaque liste

### En éditant config.json directement
Ouvre `config.json` avec un éditeur de texte (Notepad, TextEdit, VS Code)
Modifie les tableaux de valeurs, puis re-upload le fichier sur ton hébergement.

---

## Utilisateurs par défaut
| Nom | Rôle | PIN |
|-----|------|-----|
| Admin | admin | 1234 |
| Lucas Martin | commercial | 2222 |
| Sophie Rousseau | commercial | 3333 |
| Jean Hervé | poseur | 4444 |

**Pense à changer les PINs dans Paramètres → Utilisateurs après le déploiement !**

---

## Sauvegarde des données
Les données sont stockées dans le navigateur (localStorage).
- Elles restent même si tu fermes le navigateur
- Elles sont propres à chaque appareil/navigateur
- Pour une vraie base de données partagée entre plusieurs appareils, il faudra une version avec backend (contacte-nous)

---

## Support
Pour toute modification ou évolution, reviens sur la conversation Claude.
